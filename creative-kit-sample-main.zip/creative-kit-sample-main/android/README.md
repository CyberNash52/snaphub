# Creative Kit Android Sample App

To ensure that this test app works, make sure that in the <a href="https://kit.snapchat.com/portal">Snap Kit Portal</a>:

 1. you set your app's DEVELOPMENT Android Package ID to com.snapchat.kit.creativesample
 2. your Snapchat username is in the list of demo users

Then you should paste your DEVELOPMENT OAuth2 Client ID [here](creative-sample-app/src/main/AndroidManifest.xml#L25).

Build and test away! :ship:
