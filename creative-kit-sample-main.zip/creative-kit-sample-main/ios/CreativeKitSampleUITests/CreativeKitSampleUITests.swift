//
//  CreativeKitSampleUITests.swift
//  CreativeKitSampleUITests
//
//  Created by Samuel Chow on 3/27/19.
//  Copyright © 2019 Snap Inc. All rights reserved.
//

import XCTest

class CreativeKitSampleUITests: XCTestCase {
  override func setUp() {
    continueAfterFailure = false
    
    XCUIApplication().launch()
  }
  
  override func tearDown() {

  }
  
  func testExample() {

  }  
}

