//
//  CreativeKitSampleTests.swift
//  CreativeKitSampleTests
//
//  Created by Samuel Chow on 3/27/19.
//  Copyright © 2019 Snap Inc. All rights reserved.
//

import XCTest
@testable import CreativeKitSample

class CreativeKitSampleTests: XCTestCase {
  override func setUp() {

  }
  
  override func tearDown() {

  }
  
  func testExample() {

  }
  
  func testPerformanceExample() {
    self.measure {

    }
  }
}

